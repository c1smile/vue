<template>
  <div class="about">
    <Section></Section>
    <Contents></Contents>
  </div>
</template>
<script>
import Section from "@/components/smilepage/section.vue";
import Contents from "@/components/smilepage/Contents.vue";
export default {
  components: {
    Section,
    Contents
  }
};
</script>
<style scoped>
</style>
