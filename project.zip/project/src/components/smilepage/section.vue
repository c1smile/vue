<template>
  <div class="row no-gutters my-5">
    <div class="col-md-11 mx-5 px-4">
      <div class="section"></div>
      <div class="intro text-center">
        <h2 class="black" tabindex="0" style="color:;font-weight:">Brighter days are right this way.</h2>
        <p style="font-size: 24px;">
          Happiness. Hope. Joy. Confidence. A smile has the power to deliver all that, and so much more.
          <br />
          <br />In a world where things are changing fast, smiles connect us more than ever. At C1Smile-Dental, we’re taking proactive steps so that patients, care teams and communities have a safe, clean care environment for all their dental needs.
          <br />
          <br />Read our full promise of health and safety protocols
          <a
            href="https://www.aspendental.com/-/media/smile-wide-smile-safe-promise.pdf"
          >here.</a>
          <br />We look forward to seeing you!
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return { name: "Zeeshan" };
  }
};
</script>
<style scoped>
.section {
  background: url("https://www.aspendental.com/-/media/safety_page_hero.png");
  width: 100%;
  height: 500px;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 50% 50%;
}
.black {
  font-size: 60px;
}
</style>
