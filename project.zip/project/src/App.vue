<template>
  <div id="app">
    <Header></Header>
    <router-view />
    <Footer></Footer>
  </div>
</template>
<script>
import Header from "@/components/Header.vue";
import Footer from "@/components/FooterComp.vue";
export default {
  components: {
    Header,
    Footer
  }
};
</script>
<style>
</style>
